OSGB Grids
==========

A collection of Ordance Survey National Grids in Shapefile (.shp) [OSGB 1936] and GeoJSON (.geojson) [WGS84] formats.

[[Download these files](https://github.com/charlesroper/OSGB_Grids/archive/master.zip)]

<p xmlns:dct="http://purl.org/dc/terms/">
  <a rel="license"
     href="http://creativecommons.org/publicdomain/zero/1.0/">
    <img src="http://i.creativecommons.org/p/zero/1.0/88x31.png" style="border-style: none;" alt="CC0" />
  </a>
  <br />
  To the extent possible under law,
  <a rel="dct:publisher"
     href="https://github.com/charlesroper/OSGB_Grids">
    <span property="dct:title">Charles Roper</span></a>
  has waived all copyright and related or neighboring rights to
  <span property="dct:title">OSGB_Grids</span>.
</p>
